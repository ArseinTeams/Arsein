class copyright:
    __Version__ = "7.8.6"
    CopyRight = print(
        f"\n\nArsein library version {__Version__} and Api6 \n\n"
        + "Arsein Copyright (C) 2022 arianabasi Team ArianBOT\n\n\n\n"
        + "در حال فعال شدن کمی صبور باشید..."
    )
    print("........")
    print(" ")
