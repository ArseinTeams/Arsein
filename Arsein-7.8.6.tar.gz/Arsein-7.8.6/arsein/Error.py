class AuthError(Exception):
    ...


class TypeMethodError(Exception):
    ...


class TypeAnti(Exception):
    ...


class ErrorServer(Exception):
    ...


class ErrorMethod(Exception):
    ...


class ErrorPrivatyKey(Exception):
    ...


class NOT_REGISTERED(Exception):
    ...


class TOO_REQUESTS(Exception):
    ...
